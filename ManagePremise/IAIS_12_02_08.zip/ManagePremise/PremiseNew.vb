﻿Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Framework
Imports System.Runtime.InteropServices
Imports ESRI.ArcGIS.ADF.CATIDs
Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Editor
Imports ESRI.ArcGIS.Geodatabase

Imports IAIS.Windows.UI
Imports ESRI.ArcGIS.ADF.BaseClasses
Imports ESRI.ArcGIS.Carto

<CLSCompliant(False)> _
<ComClass(PremiseNew.ClassId, PremiseNew.InterfaceId, PremiseNew.EventsId)> _
Public NotInheritable Class PremiseNew
    Inherits BaseTool

    Private m_app As IApplication
    Private m_doc As IMxDocument

    Private m_Editor As IEditor
    Private m_objEvents As IObjectClassEvents_Event
    Private m_EditEvents2 As IEditEvents2_Event


    Private m_form As PremiseAttribute
    Private m_flagValidPremisePt As Boolean




#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "461500d8-d9b1-4065-94c6-67bcc658aa82"
    Public Const InterfaceId As String = "20ac3bbb-9ad5-4580-992f-887d3172a2a2"
    Public Const EventsId As String = "a9a96748-ac58-480d-811c-d7ca04ce3246"
#End Region

#Region "Component Category Registration"
    ' The below automatically adds the Component Category registration.
    <ComRegisterFunction()> Shared _
      Sub Reg(ByVal regKey As [String])
        MxCommands.Register(regKey)
    End Sub 'Reg

    <ComUnregisterFunction()> Shared _
    Sub Unreg(ByVal regKey As [String])
        MxCommands.Unregister(regKey)
    End Sub 'Unreg
#End Region

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()

        Try
            MyBase.m_bitmap = New System.Drawing.Bitmap(GetType(PremiseNew).Assembly.GetManifestResourceStream("IAIS.PremiseNew.bmp"))
        Catch
            MyBase.m_bitmap = Nothing
        End Try

        MyBase.m_caption = "Premise New"
        MyBase.m_category = "IAIS Tools"
        MyBase.m_message = "Add new premise point"
        MyBase.m_name = "IAIS Premise New"
        MyBase.m_toolTip = "Create new premise point"
    End Sub

    Public Overrides Sub OnCreate(ByVal hook As Object)
        m_app = hook
        m_doc = m_app.Document

        Dim pUid As New UID
        pUid.Value = "esriEditor.Editor"
        m_Editor = m_app.FindExtensionByCLSID(pUid)

        'm_objEvents = CType(ObjectClass, IObjectClassEvents)

    End Sub

    Public Overrides Sub OnClick()

        Dim i As Integer
        Dim edTask As IEditTask

        For i = 0 To m_Editor.TaskCount - 1
            edTask = m_Editor.Task(i)
            If edTask.Name = "Create New Feature" Then
                m_Editor.CurrentTask = edTask
                Exit For
            End If
        Next i

        Dim pUid As New UID
        pUid.Value = "{B479F48A-199D-11D1-9646-0000F8037368}"
        Dim commandItem As ICommandItem
        commandItem = m_app.Document.CommandBars.Find(pUid)
        'm_app.CurrentTool = commandItem
        If Not commandItem Is Nothing Then
            commandItem.Execute()
        End If

        Dim pEditLayers As IEditLayers
        pEditLayers = m_Editor

        Dim pMap As IMap = m_doc.FocusMap
        Dim premiseLayer As IFeatureLayer
        premiseLayer = MapUtil.GetLayerByTableName("PremsInterPt", pMap)
        pEditLayers.SetCurrentLayer(premiseLayer, 0)

        Dim pObjectClass As IObjectClass
        pObjectClass = pEditLayers.CurrentLayer.FeatureClass

        m_objEvents = CType(pObjectClass, IObjectClassEvents_Event)
        AddHandler m_objEvents.OnCreate, AddressOf OnCreatePremise

        m_EditEvents2 = CType(m_Editor, IEditEvents_Event)
        AddHandler m_EditEvents2.OnStopOperation, AddressOf OnStopCreatePremise

    End Sub

    Public Overrides ReadOnly Property Enabled() As Boolean
        Get
            Enabled = False
            If Not m_Editor Is Nothing AndAlso m_Editor.EditState <> esriEditState.esriStateNotEditing Then
                Enabled = True
            End If
        End Get
    End Property


    Sub OnCreatePremise(ByVal obj As IObject)
        Try
            Debug.Print("OnCreatePremise : " & Now & ":" & obj.OID)
            m_flagValidPremisePt = True
            If m_form IsNot Nothing AndAlso m_form.Visible Then
                If obj.OID <> m_form.PremisePt.OID Then
                    MsgBox("You have not completed the previous premise point.")
                    m_flagValidPremisePt = False
                End If
                Return
            End If

            m_form = New PremiseAttribute
            m_form.PremiseMap = m_doc.FocusMap
            m_form.PremiseApp = m_app
            m_form.PremisePt = obj
            m_form.EditMode = 1

            m_form.Show(New ModelessDialog(m_app.hWnd))

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub OnStopCreatePremise()
        If Not m_flagValidPremisePt Then
            m_doc.OperationStack.Undo()
        End If
    End Sub


End Class


