﻿Imports System.Windows.Forms
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.Editor

<CLSCompliant(False)> _
Public Class PremiseAttribute
    Private m_premiseResult As Integer
    ' Listen to the selected changed events
    Private m_map As IMap
    Private m_app As IApplication
    Private m_ActiveViewEvents As IActiveViewEvents_Event

    Private m_premsPt As IFeature

    Private m_flagGetMarSelected As Boolean
    Private m_editMode As Integer

    Public Property premiseResult() As Integer
        Get
            premiseResult = m_premiseResult
        End Get
        Set(ByVal value As Integer)
            m_premiseResult = value
        End Set
    End Property

    Public WriteOnly Property PremiseMap() As IMap
        Set(ByVal value As IMap)
            m_map = value
            m_ActiveViewEvents = CType(m_map, IActiveViewEvents_Event)
            AddHandler m_ActiveViewEvents.SelectionChanged, AddressOf OnSelectionChanged
        End Set
    End Property

    Public WriteOnly Property PremiseApp() As IApplication
        Set(ByVal value As IApplication)
            m_app = value
        End Set
    End Property

    Public Property PremisePt() As IFeature
        Get
            PremisePt = m_premsPt
        End Get
        Set(ByVal value As IFeature)
            m_premsPt = value
            updateAttribute()
        End Set
    End Property

    Public Property EditMode() As Integer
        Get
            EditMode = m_editMode
        End Get
        Set(ByVal value As Integer)
            m_editMode = value
        End Set
    End Property


    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        m_premiseResult = 1
        'Save premise point 

        Dim pUid As New UID
        pUid.Value = "esriEditor.Editor"
        Dim m_Editor As IEditor = m_app.FindExtensionByCLSID(pUid)
        m_Editor.StartOperation()
        Try
            updateFeature()
            m_premsPt.Store()
            m_Editor.StopOperation("Save Premise Point")
        Catch ex As Exception
            m_Editor.AbortOperation()
            MsgBox(ex.Message)
        End Try

        Me.Close()
    End Sub


    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        m_premiseResult = 0
        'remove the point if edit mode=1 (new premise point)
        If m_editMode = 1 Then
            'm_premsPt.Delete()
            Dim pUid As New UID
            pUid.Value = "esriEditor.Editor"
            Dim m_Editor As IEditor = m_app.FindExtensionByCLSID(pUid)

            m_Editor.StartOperation()
            Try
                m_premsPt.Delete()
                m_Editor.StopOperation("Abort Premise Point")

            Catch ex As Exception
                m_Editor.AbortOperation()
                MsgBox(ex.Message)
                Return
            End Try
        End If

        Me.Close()
    End Sub

    Private Sub btnGetMAR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetMAR.Click
        'Set select tool
        '"esriArcMapUI.SelectFeaturesTool"
        Dim pUid As New UID
        pUid.Value = "esriArcMapUI.SelectFeaturesTool"
        Dim commandItem As ICommandItem
        commandItem = m_app.Document.CommandBars.Find(pUid)
        If Not commandItem Is Nothing Then
            commandItem.Execute()
        End If

        m_flagGetMarSelected = True
    End Sub


    Sub OnSelectionChanged()
        If m_flagGetMarSelected Then

            'Get address and other information 
            Dim pLayer As IFeatureLayer
            pLayer = MapUtil.GetLayerByTableName("ADDRESSPT", m_map)
            If pLayer Is Nothing Then
                MsgBox("Can't find address point layer")
                Return
            End If

            Dim pSel As IFeatureSelection
            pSel = pLayer
            If pSel.SelectionSet.Count = 0 Then
                Return
            End If

            If pSel.SelectionSet.Count > 1 Then
                MsgBox("Please select one address point only. ")
                Return
            End If

            Dim pCur As IFeatureCursor
            pSel.SelectionSet.Search(Nothing, False, pCur)
            Dim pAddrPt As IFeature
            pAddrPt = pCur.NextFeature

            'MsgBox(pAddrPt.Value(pAddrPt.Fields.FindField("FULLADDRESS")))
            textAddr.Text = pAddrPt.Value(pAddrPt.Fields.FindField("FULLADDRES"))

            'Set falg back to false
            m_flagGetMarSelected = False
        End If
    End Sub

    Private Sub btnValidateAddr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValidateAddr.Click
        Dim MarServiceResult As gov.dc.citizenatlas.ReturnObject
        Dim LocationVerifier As gov.dc.citizenatlas.LocationVerifier = New gov.dc.citizenatlas.LocationVerifier()
        MarServiceResult = LocationVerifier.verifyDCAddress(textAddr.Text)
        Debug.Print(MarServiceResult.details)
        'MarServiceResult.returnDataset.GetXml()

        MapUtil.PrintDataSet(MarServiceResult.returnDataset)

    End Sub

    Private Sub updateAttribute()
        'PopulateDomain
        Dim fields As IFields
        fields = m_premsPt.Fields
        MapUtil.PopulateDomain(Me.ComboPexSts, fields.Field(fields.FindField("PEXPSTS")).Domain, False, MapUtil.GetValue(m_premsPt, "PEXPSTS"))
        MapUtil.PopulateDomain(Me.ComboPexPtyp, fields.Field(fields.FindField("PEXPTYP")).Domain, False, MapUtil.GetValue(m_premsPt, "PEXPTYP"))

        Me.TextAddrnum.Text = MapUtil.GetValue(m_premsPt, "ADDRNUM")
        Me.TextSTNAME.Text = MapUtil.GetValue(m_premsPt, "STNAME")

        Me.TextUNIT.Text = MapUtil.GetValue(m_premsPt, "UNIT")

        Me.textAddr.Text = MapUtil.GetValue(m_premsPt, "PEXSAD")

        Dim pexzip As String = MapUtil.GetValue(m_premsPt, "PEXPZIP")
        pexzip = Replace(pexzip, "-", "")

        Me.TextZip5.Text = Mid(pexzip, 1, 5)
        Me.TextZip4.Text = Mid(pexzip, 5, 5)

        MapUtil.PopulateDomain(Me.ComboQUADRANT, fields.Field(fields.FindField("QUADRANT")).Domain, False, MapUtil.GetValue(m_premsPt, "QUADRANT"))

        Me.TextSQUARE.Text = MapUtil.GetValue(m_premsPt, "PEXSQUARE")
        Me.TextSUFFIX.Text = MapUtil.GetValue(m_premsPt, "PEXSUFFIX")
        Me.TextLOT.Text = MapUtil.GetValue(m_premsPt, "PEXLOT")

        MapUtil.SetComboIndex(Me.ComboWARD, MapUtil.GetValue(m_premsPt, "WARD"))

        MapUtil.PopulateDomain(Me.ComboIAB_EXEMPT, fields.Field(fields.FindField("IS_EXEMPT_IAB")).Domain, False, MapUtil.GetValue(m_premsPt, "IS_EXEMPT_IAB"))
        If MapUtil.GetValue(m_premsPt, "IS_EXEMPT_IAB") = "Y" Then
            Me.ComboEXEMPT_REASON.Enabled = True
        Else
            Me.ComboEXEMPT_REASON.Enabled = False
        End If

        MapUtil.PopulateDomain(Me.ComboEXEMPT_REASON, fields.Field(fields.FindField("EXEMPT_IAB_REASON")).Domain, False, MapUtil.GetValue(m_premsPt, "EXEMPT_IAB_REASON"))
        MapUtil.PopulateDomain(Me.ComboIA_ONLY, fields.Field(fields.FindField("IS_IMPERVIOUS_ONLY")).Domain, False, MapUtil.GetValue(m_premsPt, "IS_IMPERVIOUS_ONLY"))


    End Sub


    Private Sub updateFeature()
        'PopulateDomain
        Dim fields As IFields
        fields = m_premsPt.Fields

        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("PEXPSTS"), Me.ComboPexSts.SelectedItem)
        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("PEXPTYP"), Me.ComboPexPtyp.SelectedItem)

        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("ADDRNUM"), Me.TextAddrnum.Text)
        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("STNAME"), Me.TextSTNAME.Text)

        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("UNIT"), Me.TextUNIT.Text)
        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("PEXSAD"), Me.textAddr.Text)

        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("PEXPZIP"), Me.TextZip5.Text & Me.TextZip4.Text)

        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("QUADRANT"), Me.ComboQUADRANT.SelectedItem)

        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("PEXSQUARE"), Me.TextSQUARE.Text)
        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("PEXSUFFIX"), Me.TextSUFFIX.Text)
        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("PEXLOT"), Me.TextLOT.Text)

        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("WARD"), Me.ComboWARD.SelectedItem)

        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("IS_EXEMPT_IAB"), Me.ComboIAB_EXEMPT.SelectedItem)
        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("EXEMPT_IAB_REASON"), Me.ComboEXEMPT_REASON.SelectedItem)
        MapUtil.SetFeatureValue(m_premsPt, fields.FindField("IS_IMPERVIOUS_ONLY"), Me.ComboIA_ONLY.SelectedItem)

        'Parse address?

    End Sub

    Private Sub ComboIAB_EXEMPT_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboIAB_EXEMPT.SelectedIndexChanged
        Debug.Print("ComboIAB_EXEMPT_SelectedIndexChanged: " & ComboIAB_EXEMPT.SelectedText)
        If ComboIAB_EXEMPT.SelectedItem = "YES" Then
            Me.ComboEXEMPT_REASON.Enabled = True
        Else
            Me.ComboEXEMPT_REASON.Enabled = False
        End If
    End Sub


    Private Sub btnGetSSLWard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetSSLWard.Click
        Dim wardLayer As IFeaturelayer
        Dim colLayer As ifeaturelayer

        wardLayer = MapUtil.GetLayerByTableName("ward02Ply", m_map)
        Dim pSFilter As ISpatialFilter
        pSFilter = New SpatialFilter

        pSFilter.Geometry = m_premsPt.Shape
        pSFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin

        Dim pFeatCursor As IFeatureCursor
        Dim pFeature As IFeature

        pFeatCursor = wardLayer.Search(pSFilter, False)
        pFeature = pFeatCursor.NextFeature
        If Not pFeature Is Nothing Then
            'MapUtil.SetFeatureValue(m_premsPt, m_premsPt.Fields.FindField("WARD"), MapUtil.GetValue(pFeature, "WARD_ID"))
            m_premsPt.Value(m_premsPt.Fields.FindField("WARD")) = MapUtil.GetValue(pFeature, "WARD_ID")
        End If

        colLayer = MapUtil.GetLayerByTableName("OwnerPly", m_map)
        pFeatCursor = colLayer.Search(pSFilter, False)
        pFeature = pFeatCursor.NextFeature
        If Not pFeature Is Nothing Then
            MapUtil.SetFeatureValue(m_premsPt, m_premsPt.Fields.FindField("PEXSQUARE"), MapUtil.GetValue(pFeature, "SQUARE"))
            MapUtil.SetFeatureValue(m_premsPt, m_premsPt.Fields.FindField("PEXSUFFIX"), MapUtil.GetValue(pFeature, "SUFFIX"))
            MapUtil.SetFeatureValue(m_premsPt, m_premsPt.Fields.FindField("PEXLOT"), MapUtil.GetValue(pFeature, "LOT"))
        Else
            colLayer = MapUtil.GetLayerByTableName("OwnerGapPly", m_map)
            pFeatCursor = colLayer.Search(pSFilter, False)
            pFeature = pFeatCursor.NextFeature
            If Not pFeature Is Nothing Then
                MapUtil.SetFeatureValue(m_premsPt, m_premsPt.Fields.FindField("PEXSQUARE"), MapUtil.GetValue(pFeature, "SQUARE"))
                MapUtil.SetFeatureValue(m_premsPt, m_premsPt.Fields.FindField("PEXSUFFIX"), MapUtil.GetValue(pFeature, "SUFFIX"))
                MapUtil.SetFeatureValue(m_premsPt, m_premsPt.Fields.FindField("PEXLOT"), MapUtil.GetValue(pFeature, "LOT"))
            End If
        End If


        Me.TextSQUARE.Text = MapUtil.GetValue(m_premsPt, "PEXSQUARE")
        Me.TextSUFFIX.Text = MapUtil.GetValue(m_premsPt, "PEXSUFFIX")
        Me.TextLOT.Text = MapUtil.GetValue(m_premsPt, "PEXLOT")

        MapUtil.SetComboIndex(Me.ComboWARD, MapUtil.GetValue(m_premsPt, "WARD"))


    End Sub

    Private Sub btnGetDDotAddr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetDDotAddr.Click

    End Sub
End Class
