﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSelectPremise
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DataGridPremises = New System.Windows.Forms.DataGridView
        Me.btnOk = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.MasterFlagDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.PexprmDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PexuidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PexsadDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ImperviousOnlyDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ClsPremisePtBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.DataGridPremises, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClsPremisePtBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridPremises
        '
        Me.DataGridPremises.AllowUserToAddRows = False
        Me.DataGridPremises.AllowUserToDeleteRows = False
        Me.DataGridPremises.AutoGenerateColumns = False
        Me.DataGridPremises.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridPremises.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.MasterFlagDataGridViewCheckBoxColumn, Me.PexprmDataGridViewTextBoxColumn, Me.PexuidDataGridViewTextBoxColumn, Me.PexsadDataGridViewTextBoxColumn, Me.ImperviousOnlyDataGridViewTextBoxColumn})
        Me.DataGridPremises.DataSource = Me.ClsPremisePtBindingSource
        Me.DataGridPremises.Location = New System.Drawing.Point(12, 12)
        Me.DataGridPremises.MultiSelect = False
        Me.DataGridPremises.Name = "DataGridPremises"
        Me.DataGridPremises.ReadOnly = True
        Me.DataGridPremises.RowHeadersVisible = False
        Me.DataGridPremises.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridPremises.Size = New System.Drawing.Size(411, 210)
        Me.DataGridPremises.TabIndex = 0
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(12, 228)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(136, 23)
        Me.btnOk.TabIndex = 1
        Me.btnOk.Text = "Assign Charge Feature"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(176, 228)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 2
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'MasterFlagDataGridViewCheckBoxColumn
        '
        Me.MasterFlagDataGridViewCheckBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.MasterFlagDataGridViewCheckBoxColumn.DataPropertyName = "masterFlag"
        Me.MasterFlagDataGridViewCheckBoxColumn.HeaderText = ""
        Me.MasterFlagDataGridViewCheckBoxColumn.Name = "MasterFlagDataGridViewCheckBoxColumn"
        Me.MasterFlagDataGridViewCheckBoxColumn.ReadOnly = True
        Me.MasterFlagDataGridViewCheckBoxColumn.Width = 5
        '
        'PexprmDataGridViewTextBoxColumn
        '
        Me.PexprmDataGridViewTextBoxColumn.DataPropertyName = "pexprm"
        Me.PexprmDataGridViewTextBoxColumn.HeaderText = "Premise No."
        Me.PexprmDataGridViewTextBoxColumn.Name = "PexprmDataGridViewTextBoxColumn"
        Me.PexprmDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PexuidDataGridViewTextBoxColumn
        '
        Me.PexuidDataGridViewTextBoxColumn.DataPropertyName = "pexuid"
        Me.PexuidDataGridViewTextBoxColumn.HeaderText = "Premise Id"
        Me.PexuidDataGridViewTextBoxColumn.Name = "PexuidDataGridViewTextBoxColumn"
        Me.PexuidDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PexsadDataGridViewTextBoxColumn
        '
        Me.PexsadDataGridViewTextBoxColumn.DataPropertyName = "pexsad"
        Me.PexsadDataGridViewTextBoxColumn.HeaderText = "Service Address"
        Me.PexsadDataGridViewTextBoxColumn.Name = "PexsadDataGridViewTextBoxColumn"
        Me.PexsadDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ImperviousOnlyDataGridViewTextBoxColumn
        '
        Me.ImperviousOnlyDataGridViewTextBoxColumn.DataPropertyName = "imperviousOnly"
        Me.ImperviousOnlyDataGridViewTextBoxColumn.HeaderText = "Impervious Only"
        Me.ImperviousOnlyDataGridViewTextBoxColumn.Name = "ImperviousOnlyDataGridViewTextBoxColumn"
        Me.ImperviousOnlyDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ClsPremisePtBindingSource
        '
        Me.ClsPremisePtBindingSource.DataSource = GetType(IAIS.clsPremisePt)
        '
        'FormSelectPremise
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(435, 263)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.DataGridPremises)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormSelectPremise"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Premises by Selected Parcel"
        CType(Me.DataGridPremises, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClsPremisePtBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridPremises As System.Windows.Forms.DataGridView
    Friend WithEvents ClsPremisePtBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents MasterFlagDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents PexprmDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PexuidDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PexsadDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ImperviousOnlyDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
