﻿Imports System.Windows.Forms
Imports System.Collections.Generic
Imports System.Windows.Forms.DataGridView


Public Class FormSelectPremise
    Private rowindex As Integer

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub


    Public Sub SetPremisePts(ByRef premiseList As IList)
        rowindex = -1
        DataGridPremises.DataSource = premiseList
        Dim i As Integer
        For i = 0 To premiseList.Count - 1
            Dim pt As clsPremisePt = premiseList.Item(i)
            If pt.masterFlag Then
                rowindex = i
                Exit For
            End If
        Next
    End Sub

    Private Sub FormSelectPremise_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim premiseList As IList = New List(Of clsPremisePt)
        'Dim i As Integer

        'For i = 0 To 4
        '    Dim pt As clsPremisePt = New clsPremisePt()
        '    pt.pexuid = 100 + i
        '    pt.imperviousOnly = "Y"
        '    If i = 2 Then
        '        pt.masterFlag = True
        '        rowindex = i
        '    End If
        '    pt.pexprm = "****"
        '    pt.pexsad = "100 main st"

        '    premiseList.Add(pt)
        'Next

        'DataGridPremises.DataSource = premiseList
        If rowindex >= 0 Then
            DataGridPremises.Rows(rowindex).Selected = True
        End If

        'DataGridPremises.s
        'DataGridPremises.DataBind()

    End Sub


    Private Sub DataGridPremises_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridPremises.MouseUp
        Dim hit As HitTestInfo = DataGridPremises.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell AndAlso hit.ColumnIndex = 0 Then
            Dim premiseList As IList = DataGridPremises.DataSource
            Dim i As Integer
            For i = 0 To premiseList.Count - 1
                Dim pt As clsPremisePt = premiseList.Item(i)
                If i = hit.RowIndex Then
                    pt.masterFlag = True
                    rowindex = i
                ElseIf pt.masterFlag Then
                    pt.masterFlag = False
                    DataGridPremises.InvalidateRow(i)
                End If
            Next
        End If

        If rowindex >= 0 Then
            DataGridPremises.Rows(rowindex).Selected = True
        End If
    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        'Set attribute and close form
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        'close form without making any changes
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DataGridPremises_RowErrorTextChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowEventArgs) Handles DataGridPremises.RowErrorTextChanged

    End Sub
End Class
