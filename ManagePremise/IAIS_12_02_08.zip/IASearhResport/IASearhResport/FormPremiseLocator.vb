﻿Imports System.Windows.Forms
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase
Imports IAIS.Windows.UI
Imports ESRI.ArcGIS.Framework

Public Class FormPremiseLocator

    Private m_app As IApplication
    Private m_map As IMap

    Public WriteOnly Property PremiseApp() As IApplication
        Set(ByVal value As IApplication)
            m_app = value
        End Set
    End Property

    Public Property GMap() As IMap
        Get
            Return m_map
        End Get
        Set(ByVal value As IMap)
            m_map = value
        End Set
    End Property
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        '
        Dim premiseLayer As IFeatureLayer
        Dim pCursor As IFeatureCursor
        Dim pFeature As IFeature


        Dim pQFilter As IQueryFilter = New QueryFilter
        If Trim(Me.TextPremiseNo.Text) <> "" Then
            pQFilter.WhereClause = "PEXPRM='" & Me.TextPremiseNo.Text & "'"
        ElseIf Trim(Me.TextAccountNo.Text) <> "" Then
            pQFilter.WhereClause = "PEXACT='" & Me.TextAccountNo.Text & "'"
        ElseIf Trim(Me.TextOwner.Text) <> "" Then
            pQFilter.WhereClause = "UPPER(PEXNAM) LIKE '%" & UCase(Me.TextOwner.Text) & "%'"
        End If

        premiseLayer = MapUtil.GetLayerByTableName("PremsInterPt", m_map)
        pCursor = premiseLayer.Search(pQFilter, False)
        pFeature = pCursor.NextFeature
        Dim premiseList As IList = New List(Of clsPremise)

        Dim premise As clsPremise

        Do While Not pFeature Is Nothing
            premise = New clsPremise

            premise.Pexuid = MapUtil.GetValue(pFeature, "PEXUID")
            premise.Pexprm = MapUtil.GetValue(pFeature, "PEXPRM")
            premise.Pexsad = MapUtil.GetValue(pFeature, "PEXSAD")
            premise.Owner = MapUtil.GetValue(pFeature, "PEXNAM")
            premise.Pexact = MapUtil.GetValue(pFeature, "PEXACT")
            premise.Pexptyp = MapUtil.GetValue(pFeature, "PEXPTYP", True)
            premise.Pexpsts = MapUtil.GetValue(pFeature, "PEXPSTS", True)


            premiseList.Add(premise)

            pFeature = pCursor.NextFeature
        Loop

        If premiseList.Count = 0 Then
            MsgBox("Can't find premise with given creteria.")
            Return
        End If

        If premiseList.Count = 1 Then
            premise = premiseList.Item(0)
            pQFilter.WhereClause = "PEXUID=" & premise.Pexuid
            pCursor = premiseLayer.Search(pQFilter, False)
            pFeature = pCursor.NextFeature
            MapUtil.SelectFeature(pFeature, premiseLayer)
            MapUtil.ZoomToFeature(pFeature, m_map)

            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()

            'MapUtil.FlashFeature(pFeature, m_map)

        Else

            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()

            Dim pForm As FormPremiseList = New FormPremiseList
            pForm.SetPremisePts(premiseList)
            pForm.m_map = m_map
            pForm.Show(New ModelessDialog(m_app.hWnd))

        End If

    End Sub


    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

End Class
