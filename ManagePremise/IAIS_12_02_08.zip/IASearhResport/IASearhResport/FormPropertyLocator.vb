﻿Imports System.Windows.Forms
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase

Public Class FormPropertyLocator
    Private m_map As IMap

    Public Property GMap() As IMap
        Get
            Return m_map
        End Get
        Set(ByVal value As IMap)
            m_map = value
        End Set
    End Property
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        '
        Dim colLayer As IFeatureLayer
        Dim pCursor As IFeatureCursor
        Dim pFeature As IFeature

        Dim SquarePlyFlag As Boolean = False


        Dim pSFilter As IQueryFilter = New QueryFilter

        If Trim(Me.TextLot.Text) = "" Then
            SquarePlyFlag = True
            If Trim(Me.TextSuffix.Text) = "" Then
                pSFilter.WhereClause = "SQUARE='" & Me.TextSquare.Text & "'"
            Else
                pSFilter.WhereClause = "SQUARE='" & Me.TextSquare.Text & "' AND SUFFIX='" & Me.TextSuffix.Text & "'"
            End If
        Else
            If Trim(Me.TextSuffix.Text) = "" Then
                pSFilter.WhereClause = "SQUARE='" & Me.TextSquare.Text & "' AND LOT='" & Me.TextLot.Text & "'"
            Else
                pSFilter.WhereClause = "SQUARE='" & Me.TextSquare.Text & _
                                        "' AND SUFFIX='" & Me.TextSuffix.Text & _
                                        "' AND LOT='" & Me.TextLot.Text & "'"
            End If
        End If


        If Not SquarePlyFlag Then
            colLayer = MapUtil.GetLayerByTableName("OwnerPly", m_map)
            pCursor = colLayer.Search(pSFilter, False)
            pFeature = pCursor.NextFeature

            If Not pFeature Is Nothing Then
                MapUtil.SelectFeature(pFeature, colLayer)
                MapUtil.ZoomToFeature(pFeature, m_map)
            Else
                colLayer = MapUtil.GetLayerByTableName("OwnerGapPly", m_map)
                pCursor = colLayer.Search(pSFilter, False)
                pFeature = pCursor.NextFeature

                If Not pFeature Is Nothing Then
                    MapUtil.SelectFeature(pFeature, colLayer)
                    MapUtil.ZoomToFeature(pFeature, m_map)
                End If
            End If

            If pFeature Is Nothing Then
                MsgBox("Can't find property with given SSL.")
                Return
            End If
        Else
            colLayer = MapUtil.GetLayerByTableName("SquarePly", m_map)
            pCursor = colLayer.Search(pSFilter, False)
            pFeature = pCursor.NextFeature

            If Not pFeature Is Nothing Then
                MapUtil.SelectFeature(pFeature, colLayer)
                MapUtil.ZoomToFeature(pFeature, m_map)
            Else
                MsgBox("Can't find property with given SSL.")
                Return
            End If
        End If


        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()

        MapUtil.FlashFeature(pFeature, m_map)
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

End Class
