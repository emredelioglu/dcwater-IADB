﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase

Public Class FormPremiseList
    Protected Friend m_map As imap

    Public Sub SetPremisePts(ByRef premiseList As IList)
        DataGridPremises.DataSource = premiseList
    End Sub

    Private Sub DataGridPremises_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridPremises.MouseClick
        Dim hit As System.Windows.Forms.DataGridView.HitTestInfo = DataGridPremises.HitTest(e.X, e.Y)
        Dim pFeature As IFeature
        Dim premiseLayer As IFeatureLayer = MapUtil.GetLayerByTableName("PremsInterPt", m_map)
        If hit.Type = System.Windows.Forms.DataGridViewHitTestType.Cell Then
            If hit.ColumnIndex = 0 Then
                'zoom to feature
                pFeature = GetPremise(m_map, DataGridPremises.SelectedRows.Item(0).Cells.Item(8).Value)
                MapUtil.SelectFeature(pFeature, premiseLayer)
                MapUtil.ZoomToFeature(pFeature, m_map)
            ElseIf hit.ColumnIndex = 1 Then
                'pan to feature
                pFeature = GetPremise(m_map, DataGridPremises.SelectedRows.Item(0).Cells.Item(8).Value)
                MapUtil.SelectFeature(pFeature, premiseLayer)
                MapUtil.PanToFeature(pFeature, m_map)
            End If
        End If
    End Sub

    Private Sub DataGridPremises_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridPremises.SelectionChanged
        'DataGridPremises.SelectedRows.Count
        'flash the selected feature
    End Sub


    Private Function GetPremise(ByRef pMap As IMap, ByVal pexuid As String) As IFeature
        Dim premiseLayer As IFeatureLayer
        premiseLayer = MapUtil.GetLayerByTableName("PremsInterPt", m_map)
        Dim pFilter As IQueryFilter = New QueryFilter
        pFilter.WhereClause = "PEXUID=" & pexuid
        Dim pCursor As IFeatureCursor
        pCursor = premiseLayer.Search(pFilter, False)
        Return pCursor.NextFeature
    End Function
End Class