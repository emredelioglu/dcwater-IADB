﻿Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Carto

Public Class IAToolUtil
    Public Shared Function GetTargetLayer(ByRef app As IApplication) As IFeatureLayer
        Dim pUid As New UID
        pUid.Value = "IAIS.IASourceListControl"
        Dim commandItem As ICommandItem
        commandItem = app.Document.CommandBars.Find(pUid)

        Dim sourceList As IASourceListControl
        sourceList = commandItem.Command

        If sourceList.ComboTargetList.SelectedItem = "" Then
            Return Nothing
        End If

        Dim pDoc As IMxDocument
        pDoc = app.Document
        Return MapUtil.GetLayerByTableName(sourceList.ComboTargetList.SelectedItem, pDoc.FocusMap)

    End Function


    Public Shared Function GetSourceLayer(ByRef app As IApplication) As ILayer
        Dim pUid As New UID
        pUid.Value = "IAIS.IASourceListControl"
        Dim commandItem As ICommandItem
        commandItem = app.Document.CommandBars.Find(pUid)

        Dim sourceList As IASourceListControl
        sourceList = commandItem.Command

        If sourceList.ComboSourceList.SelectedItem = "" Then
            Return Nothing
        End If

        Dim pDoc As IMxDocument
        pDoc = app.Document

        If sourceList.ComboSourceList.SelectedItem = "Scratch" Then
            Return MapUtil.GetLayerByTableName("ScratchIAPly", pDoc.FocusMap)
        Else
            Return MapUtil.GetGroupLayer("DCGIS IA Layers", pDoc.FocusMap)
        End If
    End Function

    Public Shared Function GetIAType(ByVal tablename As String) As Integer
        Return 0
    End Function


    Public Shared Function GetSSL(ByVal square As String, ByVal suffix As String, ByVal lot As String) As String
        If Trim(suffix) = "" Then
            suffix = "    "
        End If

        Return square & suffix & lot

    End Function
End Class
