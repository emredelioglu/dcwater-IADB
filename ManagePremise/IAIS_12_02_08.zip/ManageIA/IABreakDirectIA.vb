﻿
Imports ESRI.ArcGIS.ADF.BaseClasses
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Editor

Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.Geometry
Imports System.Runtime.InteropServices
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.ADF.CATIDs

<CLSCompliant(False)> _
<ComClass(IABreakDirectIA.ClassId, IABreakDirectIA.InterfaceId, IABreakDirectIA.EventsId)> _
<ProgId("IAIS.IABreakDirectIA")> _
Public Class IABreakDirectIA
    Inherits BaseCommand
#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "e3425a78-c870-43be-b74e-97b5f9460021"
    Public Const InterfaceId As String = "737a25af-966b-425b-b24d-6a8a9150a5fe"
    Public Const EventsId As String = "c560b8bf-68b4-426b-ac9b-4e7415802b82"
#End Region

    Private m_app As IApplication
    Private m_doc As IMxDocument

    Private m_Editor As IEditor


#Region "Component Category Registration"
    ' The below automatically adds the Component Category registration.
    <ComRegisterFunction()> Shared _
      Sub Reg(ByVal regKey As [String])
        MxCommands.Register(regKey)
    End Sub 'Reg

    <ComUnregisterFunction()> Shared _
    Sub Unreg(ByVal regKey As [String])
        MxCommands.Unregister(regKey)
    End Sub


#End Region

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()

        Try
            MyBase.m_bitmap = New System.Drawing.Bitmap(GetType(IABuldAssignment).Assembly.GetManifestResourceStream("IAIS.ia_break_ia_direct_assign.bmp"))
        Catch
            MyBase.m_bitmap = Nothing
        End Try

        MyBase.m_caption = "Break Direct IA Assign"
        MyBase.m_category = "IAIS Tools"
        MyBase.m_message = "Break Direct IA Assign"
        MyBase.m_name = "Break Direct IA Assign"
        MyBase.m_toolTip = "Break Direct IA Assign"
    End Sub


    Public Overrides Sub OnClick()

        Dim pMap As IMap
        pMap = m_doc.FocusMap

        Dim premiseLayer As IFeatureLayer
        premiseLayer = MapUtil.GetLayerByTableName("PremsInterPt", pMap)

        Dim pSel As IFeatureSelection
        Dim pFeatCursor As IFeatureCursor
        Dim pPt As IFeature

        pSel = premiseLayer
        pSel.SelectionSet.Search(Nothing, False, pFeatCursor)
        pPt = pFeatCursor.NextFeature

        Dim iaLayer As IFeatureLayer
        Dim ia As IFeature



        m_Editor.StartOperation()
        Try
            'remove the IS_DIRECT_IAASSIGN for selected premise
            pPt.Value(pPt.Fields.FindField("IS_DIRECT_IAASSIGN")) = System.DBNull.Value
            pPt.Store()

            'remove PEXUID from ia layers one by one 
            iaLayer = MapUtil.GetLayerByTableName("IAAssignPly", pMap)
            pSel = iaLayer
            pSel.SelectionSet.Search(Nothing, False, pFeatCursor)
            ia = pFeatCursor.NextFeature
            Do While Not ia Is Nothing
                ia.Value(ia.Fields.FindField("PEXUID")) = System.DBNull.Value
                ia.Store()

                ia = pFeatCursor.NextFeature
            Loop

            iaLayer = MapUtil.GetLayerByTableName("RevIAAssignPly", pMap)
            pSel = iaLayer
            pSel.SelectionSet.Search(Nothing, False, pFeatCursor)
            ia = pFeatCursor.NextFeature
            Do While Not ia Is Nothing
                ia.Value(ia.Fields.FindField("PEXUID")) = System.DBNull.Value
                ia.Store()

                ia = pFeatCursor.NextFeature
            Loop

            iaLayer = MapUtil.GetLayerByTableName("AppealIAAssignPly", pMap)
            pSel = iaLayer
            pSel.SelectionSet.Search(Nothing, False, pFeatCursor)
            ia = pFeatCursor.NextFeature
            Do While Not ia Is Nothing
                ia.Value(ia.Fields.FindField("PEXUID")) = System.DBNull.Value
                ia.Store()

                ia = pFeatCursor.NextFeature
            Loop

            m_Editor.StopOperation("Break Direct IA Assign")

            Return
        Catch ex As Exception
            m_Editor.AbortOperation()
            MsgBox(ex.Message)
        End Try


    End Sub

    ''' <param name="hook">
    ''' A reference to the application in which the command was created.
    '''            The hook may be an IApplication reference (for commands created in ArcGIS Desktop applications)
    '''            or an IHookHelper reference (for commands created on an Engine ToolbarControl).
    ''' </param>
    Public Overrides Sub OnCreate(ByVal hook As Object)
        m_app = hook
        m_doc = m_app.Document

        Dim pUid As New UID
        pUid.Value = "esriEditor.Editor"
        m_Editor = m_app.FindExtensionByCLSID(pUid)

    End Sub

    Public Overrides ReadOnly Property Enabled() As Boolean
        Get
            Try
                If m_Editor Is Nothing Then
                    Return False
                End If

                If m_Editor.EditState = esriEditState.esriStateNotEditing Then
                    Return False
                End If

                Dim pMap As IMap = m_doc.FocusMap

                Dim premiseLayer As IFeatureLayer
                premiseLayer = MapUtil.GetLayerByTableName("PremsInterPt", pMap)


                If premiseLayer Is Nothing Then
                    Return False
                End If

                Dim pFeatSel As IFeatureSelection
                pFeatSel = premiseLayer
                Return (pFeatSel.SelectionSet.Count = 1)

            Catch ex As Exception
                Return False
            End Try
        End Get
    End Property 'Unreg
End Class


