﻿Imports System.Runtime.InteropServices
Imports ESRI.ArcGIS.ADF.CATIDs
Imports ESRI.ArcGIS.ADF.BaseClasses
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Editor

Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.Geometry

<CLSCompliant(False)> _
<ComClass(IABuldManual.ClassId, IABuldManual.InterfaceId, IABuldManual.EventsId)> _
<ProgId("IAIS.IABuldManual")> _
Public Class IABuldManual
    Inherits BaseTool

    Private m_app As IApplication
    Private m_doc As IMxDocument
    Private m_map As IMap

    Private m_Editor As IEditor

    Private m_buld As IFeature
    Private m_col As IFeature

    Private m_isScratch As Boolean


#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "5e8379f8-f999-47cf-8e5b-f9d302bf8a38"
    Public Const InterfaceId As String = "822fcc1c-ea87-4105-b48a-29a1038c76ab"
    Public Const EventsId As String = "1a959e05-ffe2-406a-8d0c-729051b7585f"
#End Region

#Region "Component Category Registration"
    ' The below automatically adds the Component Category registration.
    <ComRegisterFunction()> Shared _
      Sub Reg(ByVal regKey As [String])
        MxCommands.Register(regKey)
    End Sub 'Reg

    <ComUnregisterFunction()> Shared _
    Sub Unreg(ByVal regKey As [String])
        MxCommands.Unregister(regKey)
    End Sub 'Unreg
#End Region
    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()

        Try
            MyBase.m_bitmap = New System.Drawing.Bitmap(GetType(IABuldAssignment).Assembly.GetManifestResourceStream("IAIS.ia_building_manual.bmp"))
        Catch
            MyBase.m_bitmap = Nothing
        End Try

        MyBase.m_caption = "Building Assignment(Manual)"
        MyBase.m_category = "IAIS Tools"
        MyBase.m_message = "Building Assignment(Manual)"
        MyBase.m_name = "Building Assignment(Manual)"
        MyBase.m_toolTip = "Building Assignment(Manual)"

    End Sub

    Public Overrides Sub OnClick()
        m_map = m_doc.FocusMap
    End Sub

    ''' <param name="hook">
    ''' A reference to the application in which the command was created.
    '''            The hook may be an IApplication reference (for commands created in ArcGIS Desktop applications)
    '''            or an IHookHelper reference (for commands created on an Engine ToolbarControl).
    ''' </param>
    Public Overrides Sub OnCreate(ByVal hook As Object)
        m_app = hook
        m_doc = m_app.Document

        Dim pUid As New UID
        pUid.Value = "esriEditor.Editor"
        m_Editor = m_app.FindExtensionByCLSID(pUid)
    End Sub

    ''' <param name="Button">Specifies which mouse button is released; 1 for the left mouse button, 2 for the right mouse button, and 4 for the middle mouse button.</param>
    ''' <param name="Shift">Specifies an integer corresponding to the state of the SHIFT (bit 0), CTRL (bit 1) and ALT (bit 2) keys. When none, some, or all of these keys are pressed none, some, or all the bits get set. These bits correspond to the values 1, 2, and 4, respectively. For example, if both SHIFT and ALT were pressed, Shift would be 5.</param>
    ''' <param name="X">The X coordinate, in device units, of the location of the mouse event. See the OnMouseUp Event for more details.</param>
    ''' <param name="Y">The Y coordinate, in device units, of the location of the mouse event. See the OnMouseUp Event for more details.</param>
    Public Overrides Sub OnMouseUp(ByVal Button As Integer, ByVal Shift As Integer, ByVal X As Integer, ByVal Y As Integer)
        Dim pPt As IPoint
        pPt = m_Editor.Display.DisplayTransformation.ToMapPoint(X, Y)

        Dim pSFilter As ISpatialFilter = New SpatialFilter
        pSFilter.Geometry = pPt
        pSFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelWithin

        Dim pLayer As IFeatureLayer
        Dim pCursor As IFeatureCursor
        Dim pFeatSel As IFeatureSelection

        If m_buld Is Nothing Then
            m_isScratch = False
            Dim sourceLayer As ILayer = IAToolUtil.GetSourceLayer(m_app)
            If TypeOf sourceLayer Is IFeatureLayer Then
                pLayer = sourceLayer
                m_isScratch = True
            Else
                pLayer = MapUtil.GetLayerByTableName("BldgPly", m_map)
            End If

            pCursor = pLayer.Search(pSFilter, False)
            m_buld = pCursor.NextFeature
            If Not m_buld Is Nothing Then
                pFeatSel = pLayer
                pFeatSel.Clear()
                pFeatSel.SelectionSet.Add(m_buld.OID)
                m_doc.ActiveView.Refresh()
            End If

            Return
        Else
            'find parcel
            pLayer = MapUtil.GetLayerByTableName("OwnerPly", m_map)
            pCursor = pLayer.Search(pSFilter, False)
            m_col = pCursor.NextFeature
            If m_col Is Nothing Then
                pLayer = MapUtil.GetLayerByTableName("OwnerGapPly", m_map)
                pCursor = pLayer.Search(pSFilter, False)
                m_col = pCursor.NextFeature
            End If

            If Not m_col Is Nothing Then
                'Assign the building to polygon

                m_Editor.StartOperation()
                Try
                    Dim iaFeature As IFeature
                    Dim targetIALayer As IFeatureLayer = IAToolUtil.GetTargetLayer(m_app)
                    iaFeature = targetIALayer.FeatureClass.CreateFeature

                    iaFeature.Shape = m_buld.ShapeCopy
                    iaFeature.Value(iaFeature.Fields.FindField("IAID")) = iaFeature.OID 'Should we get a sequence id here?
                    iaFeature.Value(iaFeature.Fields.FindField("OWNER_GIS_ID")) = MapUtil.GetValue(m_col, "GIS_ID")
                    iaFeature.Value(iaFeature.Fields.FindField("SSL")) = MapUtil.GetValue(m_col, "SSL")
                    iaFeature.Value(iaFeature.Fields.FindField("FEATURETYPE")) = MapUtil.FEATURETYPE_BUILDING
                    iaFeature.Value(iaFeature.Fields.FindField("ASSIGNBUILD")) = 2

                    iaFeature.Value(iaFeature.Fields.FindField("PROCESSDT")) = Now

                    If m_isScratch Then
                        iaFeature.Value(iaFeature.Fields.FindField("FEATUREOID")) = m_buld.OID
                    Else
                        iaFeature.Value(iaFeature.Fields.FindField("FEATUREOID")) = MapUtil.GetValue(m_buld, "GIS_ID")
                    End If


                    Dim impAreaPoly As IPolygon = m_buld.Shape
                    iaFeature.Value(iaFeature.Fields.FindField("IARSQM")) = MapUtil.GetPlyArea(impAreaPoly)
                    iaFeature.Value(iaFeature.Fields.FindField("IARSQF")) = MapUtil.GetPlyArea(impAreaPoly) * 10.763910417
                    iaFeature.Store()

                    m_Editor.StopOperation("Building Assignment (manual)")

                    m_buld = Nothing
                    m_col = Nothing
                    m_doc.ActiveView.Refresh()

                    Return
                Catch ex As Exception
                    m_Editor.AbortOperation()
                    MsgBox(ex.Message)
                    m_buld = Nothing
                    m_col = Nothing

                    m_doc.FocusMap.ClearSelection()
                    Return
                End Try

            End If
        End If


    End Sub

    Public Overrides ReadOnly Property Enabled() As Boolean
        Get
            Try
                If m_Editor Is Nothing Then
                    Return False
                End If

                If m_Editor.EditState = esriEditState.esriStateNotEditing Then
                    Return False
                End If

                Return (Not IAToolUtil.GetSourceLayer(m_app) Is Nothing And _
                        Not IAToolUtil.GetTargetLayer(m_app) Is Nothing)

            Catch ex As Exception
                Return False
            End Try
        End Get
    End Property 'Unreg

End Class


