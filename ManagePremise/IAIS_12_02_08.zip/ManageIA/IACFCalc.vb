﻿Imports ESRI.ArcGIS.ADF.BaseClasses
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Editor

Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.Geometry
Imports System.Runtime.InteropServices
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.ADF.CATIDs

<CLSCompliant(False)> _
<ComClass(IACFCalc.ClassId, IACFCalc.InterfaceId, IACFCalc.EventsId)> _
<ProgId("IAIS.IACFCalc")> _
Public Class IACFCalc
    Inherits BaseCommand

    Private m_app As IApplication
    Private m_doc As IMxDocument
    Private m_Editor As IEditor

#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "e3238408-fe03-4b4e-935b-47336cc6f2a2"
    Public Const InterfaceId As String = "b21270e2-9a06-4e87-8542-3863935a0d6a"
    Public Const EventsId As String = "2f884f4e-74be-4a39-9265-0602574521e5"
#End Region

#Region "Component Category Registration"
    ' The below automatically adds the Component Category registration.
    <ComRegisterFunction()> Shared _
      Sub Reg(ByVal regKey As [String])
        MxCommands.Register(regKey)
    End Sub 'Reg

    <ComUnregisterFunction()> Shared _
    Sub Unreg(ByVal regKey As [String])
        MxCommands.Unregister(regKey)
    End Sub


#End Region

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()

        Try
            MyBase.m_bitmap = New System.Drawing.Bitmap(GetType(IABuldAssignment).Assembly.GetManifestResourceStream("IAIS.ia_calc_charges.bmp"))
        Catch
            MyBase.m_bitmap = Nothing
        End Try

        MyBase.m_caption = "Calculate IA Charges"
        MyBase.m_category = "IAIS Tools"
        MyBase.m_message = "Calculate IA Charges"
        MyBase.m_name = "Calculate IA Charges"
        MyBase.m_toolTip = "Calculate IA Charges"

    End Sub

    Public Overrides Sub OnClick()
        Dim pMap As IMap
        pMap = m_doc.FocusMap

        Dim premiseLayer As IFeatureLayer
        premiseLayer = MapUtil.GetLayerByTableName("PremsInterPt", pMap)

        Dim pSel As IFeatureSelection
        pSel = premiseLayer
        Dim pFeatCursor As IFeatureCursor
        pSel.SelectionSet.Search(Nothing, False, pFeatCursor)

        Dim pPt As IFeature
        pPt = pFeatCursor.NextFeature

        If MapUtil.GetValue(pPt, "IS_EXEMPT_IAB") = "Y" Then
            MsgBox("Selected premise point is IAB exempted.")
            Return
        End If

        If Not pPt Is Nothing Then
            'Get the ssl of premise
            Dim ssl As String
            ssl = IAToolUtil.GetSSL(MapUtil.GetValue(pPt, "PEXSQUARE"), _
                    MapUtil.GetValue(pPt, "PEXSUFFIX"), _
                    MapUtil.GetValue(pPt, "PEXLOT"))

            'Get everything from IAAssignPly layer
            Dim iaCursor As IFeatureCursor
            Dim iaLayer As IFeatureLayer
            Dim ia As IFeature
            Dim pQFilter As IQueryFilter = New QueryFilter
            pQFilter.WhereClause = "SSL='" & ssl & "'"

            Dim iasqft As Double = 0
            Dim iaeru As Double = 0

            iaLayer = MapUtil.GetLayerByTableName("IAAssignPly", pMap)
            iaCursor = iaLayer.Search(pQFilter, False)
            ia = iaCursor.NextFeature
            Do While Not ia Is Nothing
                iasqft = iasqft + ia.Value(ia.Fields.FindField("IARSQF"))
                ia = iaCursor.NextFeature
            Loop

            iaLayer = MapUtil.GetLayerByTableName("RevIAAssignPly", pMap)
            iaCursor = iaLayer.Search(pQFilter, False)
            ia = iaCursor.NextFeature
            Do While Not ia Is Nothing
                iasqft = iasqft + ia.Value(ia.Fields.FindField("IARSQF"))
                ia = iaCursor.NextFeature
            Loop

            iaLayer = MapUtil.GetLayerByTableName("AppealIAAssignPly", pMap)
            iaCursor = iaLayer.Search(pQFilter, False)
            ia = iaCursor.NextFeature
            Do While Not ia Is Nothing
                iasqft = iasqft + ia.Value(ia.Fields.FindField("IARSQF"))
                ia = iaCursor.NextFeature
            Loop

            If MapUtil.GetValue(pPt, "PEXPTYP") = "RES" Then
                iaeru = 1
            Else
                iaeru = FormatNumber(iasqft / 1000, 1)
            End If

            If iasqft > 0 Then

                Dim pForm As FormPickDate
                pForm = New FormPickDate
                pForm.ShowDialog()

                m_Editor.StartOperation()
                Try
                    Dim pdataset As IDataset
                    pdataset = premiseLayer
                    Dim iacfTable As ITable = MapUtil.GetTableFromWS(CType(pdataset.Workspace, IFeatureWorkspace), "IACF")
                    Dim iacfRow As IRow

                    iacfRow = iacfTable.CreateRow

                    iacfRow.Value(iacfRow.Fields.FindField("PEXUID")) = MapUtil.GetValue(pPt, "PEXUID")
                    iacfRow.Value(iacfRow.Fields.FindField("IABILLERU")) = iaeru
                    iacfRow.Value(iacfRow.Fields.FindField("IASQFT")) = iasqft
                    iacfRow.Value(iacfRow.Fields.FindField("DBSTAMPDT")) = Now
                    iacfRow.Value(iacfRow.Fields.FindField("EFFSTARTDT")) = pForm.DateTimePicker1.Text

                    iacfRow.Store()

                    m_Editor.StopOperation("Calculate Charges")

                Catch ex As Exception
                    m_Editor.AbortOperation()
                    MsgBox(ex.Message)
                    Return
                End Try

            Else
                MsgBox("There is no IA area assigned to the selected premise.")
            End If


        End If

    End Sub

    ''' <param name="hook">
    ''' A reference to the application in which the command was created.
    '''            The hook may be an IApplication reference (for commands created in ArcGIS Desktop applications)
    '''            or an IHookHelper reference (for commands created on an Engine ToolbarControl).
    ''' </param>
    Public Overrides Sub OnCreate(ByVal hook As Object)
        m_app = hook
        m_doc = m_app.Document

        Dim pUid As New UID
        pUid.Value = "esriEditor.Editor"
        m_Editor = m_app.FindExtensionByCLSID(pUid)
    End Sub 'Unreg

    Public Overrides ReadOnly Property Enabled() As Boolean
        Get
            Try
                If m_Editor Is Nothing Then
                    Return False
                End If

                If m_Editor.EditState = esriEditState.esriStateNotEditing Then
                    Return False
                End If

                Dim pMap As IMap = m_doc.FocusMap

                Dim pColLayer As IFeatureLayer
                pColLayer = MapUtil.GetLayerByTableName("PremsInterPt", pMap, False)

                If pColLayer Is Nothing Then
                    Return False
                End If

                Dim pFeatSel As IFeatureSelection
                pFeatSel = pColLayer
                Return (pFeatSel.SelectionSet.Count = 1)

            Catch ex As Exception
                Return False
            End Try
        End Get
    End Property 'Unreg
End Class


